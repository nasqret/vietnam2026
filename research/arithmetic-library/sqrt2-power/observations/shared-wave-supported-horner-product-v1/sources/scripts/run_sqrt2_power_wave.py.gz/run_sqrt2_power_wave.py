#!/usr/bin/env python3
"""Source-pinned, sequential proof-DAG/reconstruction observations, not admissions.

Each target is rebound independently in a fresh ordinary HA replay process.
Artifacts are lossless and append-only. Run under the reviewed OS supervisor;
no kernel limits, axioms, parent campaign status, or deployed files are changed.
"""
from dataclasses import replace
from hashlib import sha256
import argparse
import gzip
import json
from pathlib import Path
import sys
import time

from run_sqrt2_power_pilot import (
    ROOT, LeafBudget, controller_deadline, successful, save_new,
)
from sqrt2_power_automation_baseline import runtime
from sqrt2_power_pilot_contracts import canonical
from sqrt2_power_binary_dag import BinaryDAGLimits, formula_sha256
from peano_lab.kernel.formulas import Bot
from peano_lab.kernel.proofs import EqRefl
from peano_lab.kernel.terms import Zero
from peano_lab.library.proof_bundle import (
    BundleNode, ProofBundle, ProofBundleError, check_proof_bundle,
    decode_proof_bundle, encode_proof_bundle,
)

SCHEMA = "sqrt2-power-shared-proof-wave-v1"
SCRIPT = Path(__file__).resolve()
FOUNDATION_CASES = dict(RF001="irat_eq_reflexive", RF002="irat_eq_symmetric",
    RF003="irat_eq_transitive", RF004="irat_eq_scale_nonzero",
    RF005="irat_eq_numerator_shift", RF006="irat_eq_negation_compatible")
CHUNK_CASES = tuple(f"P04-C{i:02d}" for i in range(16))
CASES = ("P10", "P08-eprover", "P08-vampire", "P04-ground", "P04-soundness", "IR016",
         "SN001", "NG001", "SN002", "SN003", "CV001", "CV002", "CV003", "CV004", "CV005", "CV006", "CV007", "CV008", "CV009", "CV010", "CV011", "CV012", "CV013", "CV014", "CV015", "CV016", "CV017", "CV018", "CV019", "CV020", "CV021", "CV022", "CV023", "CV024", "CV025", "CV026", "CV027", "CV028", "CV029", "CV030", "CV031", "CV032", "CV033", "CV034", "CV035", "CV036", "CV037", "CV038", "CV039", "CV040", "CV041", "CV042", "RN001", "RN002", "SI001",
         "CV043", "CV044", "CV045", "CV046", "CV047", "CV048", "CV049", "CV050", "CV051", "CV052", "CV053", "CV054", "CV055", "CV056", "QN001", "QF001", "QF002", "QF003", "QH001", "QF004", "QH002", "QF005", *FOUNDATION_CASES, *CHUNK_CASES)
LIMITS = BinaryDAGLimits().bundle_limits()


def pins(identifier):
    from sqrt2_power_solver_hints import source_pins
    result = source_pins()
    for name in (SCRIPT.name, "run_sqrt2_power_pilot.py", "sqrt2_power_binary_dag.py",
                 "sqrt2_power_pilot_instances.py"):
        path = ROOT / "scripts" / name
        result[str(path.relative_to(ROOT))] = runtime().hash_file(path)
    if identifier.startswith("P04-"):
        path = ROOT / "scripts/sqrt2_power_formal_composition.py"
        result[str(path.relative_to(ROOT))] = runtime().hash_file(path)
    if identifier in CHUNK_CASES:
        path = ROOT / "scripts/sqrt2_power_composition_chunks.py"
        result[str(path.relative_to(ROOT))] = runtime().hash_file(path)
    if identifier in FOUNDATION_CASES:
        from sqrt2_power_rational_foundations import source_pins as foundation_pins
        result.update(foundation_pins())
    if identifier == "IR016":
        from sqrt2_power_even_square import FERMAT_ARTIFACT, FERMAT_SOURCE_PATH
        for path in (ROOT / "scripts/sqrt2_power_even_square.py", FERMAT_ARTIFACT, ROOT / FERMAT_SOURCE_PATH):
            result[str(path.relative_to(ROOT))] = runtime().hash_file(path)
    if identifier == "SN001":
        from sqrt2_power_signed_norm import signed_norm_source_pins
        result.update(signed_norm_source_pins())
    if identifier in ("NG001", "SN002"):
        from sqrt2_power_norm_separation import norm_separation_source_pins
        result.update(norm_separation_source_pins())
    if identifier == "SN003":
        from sqrt2_power_quadratic_norm_product import norm_product_source_pins
        result.update(norm_product_source_pins())
    if identifier == "CV001":
        from sqrt2_power_convolution_vanishing import convolution_source_pins
        result.update(convolution_source_pins())
    if identifier == "CV002":
        from sqrt2_power_logexp_recurrence import logexp_recurrence_source_pins
        result.update(logexp_recurrence_source_pins())
    if identifier == "CV003":
        from sqrt2_power_natural_convolution import natural_convolution_source_pins
        result.update(natural_convolution_source_pins())
    if identifier == "CV004":
        from sqrt2_power_series_power_trace import series_power_trace_source_pins
        result.update(series_power_trace_source_pins())
    if identifier == "CV005":
        from sqrt2_power_series_power_vanishing import series_power_vanishing_source_pins
        result.update(series_power_vanishing_source_pins())
    if identifier == "CV006":
        from sqrt2_power_sum_linearity import sum_linearity_source_pins
        result.update(sum_linearity_source_pins())
    if identifier == "CV007":
        from sqrt2_power_euler_product import euler_product_source_pins
        result.update(euler_product_source_pins())
    if identifier == "CV008":
        from sqrt2_power_natural_fubini import natural_fubini_source_pins
        result.update(natural_fubini_source_pins())
    if identifier == "CV009":
        from sqrt2_power_sum_splitting import sum_splitting_source_pins
        result.update(sum_splitting_source_pins())
    if identifier == "CV010":
        from sqrt2_power_convolution_commutative import convolution_commutative_source_pins
        result.update(convolution_commutative_source_pins())
    if identifier == "CV011":
        from sqrt2_power_sum_zero_tail import sum_zero_tail_source_pins
        result.update(sum_zero_tail_source_pins())
    if identifier == "CV012":
        from sqrt2_power_triple_grid import triple_grid_source_pins
        result.update(triple_grid_source_pins())
    if identifier == "CV013":
        from sqrt2_power_triple_row_sum import triple_row_sum_source_pins
        result.update(triple_row_sum_source_pins())
    if identifier == "CV014":
        from sqrt2_power_convolution_associative import convolution_associative_source_pins
        result.update(convolution_associative_source_pins())
    if identifier == "CV015":
        from sqrt2_power_convolution_linearity import convolution_linearity_source_pins
        result.update(convolution_linearity_source_pins())
    if identifier == "CV016":
        from sqrt2_power_convolution_unit import convolution_unit_source_pins
        result.update(convolution_unit_source_pins())
    if identifier == "CV017":
        from sqrt2_power_series_power_euler import series_power_euler_source_pins
        result.update(series_power_euler_source_pins())
    if identifier == "CV018":
        from sqrt2_power_series_linear_combination import series_linear_combination_source_pins
        result.update(series_linear_combination_source_pins())
    if identifier == "CV019":
        from sqrt2_power_weighted_series_trace import weighted_series_trace_source_pins
        result.update(weighted_series_trace_source_pins())
    if identifier == "CV020":
        from sqrt2_power_shifted_euler_prefix import shifted_euler_prefix_source_pins
        result.update(shifted_euler_prefix_source_pins())
    if identifier == "CV021":
        from sqrt2_power_finite_composition_euler import finite_composition_euler_source_pins
        result.update(finite_composition_euler_source_pins())
    if identifier == "CV022":
        from sqrt2_power_exponential_weights import exponential_weights_source_pins
        result.update(exponential_weights_source_pins())
    if identifier == "CV023":
        from sqrt2_power_weighted_series_scaling import weighted_series_scaling_source_pins
        result.update(weighted_series_scaling_source_pins())
    if identifier == "CV024":
        from sqrt2_power_denominator_euler import denominator_euler_source_pins
        result.update(denominator_euler_source_pins())
    if identifier == "CV025":
        from sqrt2_power_atanh_coefficients import atanh_coefficients_source_pins
        result.update(atanh_coefficients_source_pins())
    if identifier == "CV026":
        from sqrt2_power_atanh_euler import atanh_euler_source_pins
        result.update(atanh_euler_source_pins())
    if identifier == "CV027":
        from sqrt2_power_periodic_convolution import periodic_convolution_source_pins
        result.update(periodic_convolution_source_pins())
    if identifier == "CV028":
        from sqrt2_power_composition_recurrence import composition_recurrence_source_pins
        result.update(composition_recurrence_source_pins())
    if identifier == "CV029":
        from sqrt2_power_composition_coefficients import composition_coefficients_source_pins
        result.update(composition_coefficients_source_pins())
    if identifier == "CV030":
        from sqrt2_power_weight_factorials import weight_factorials_source_pins
        result.update(weight_factorials_source_pins())
    if identifier == "CV031":
        from sqrt2_power_normalized_composition import normalized_composition_source_pins
        result.update(normalized_composition_source_pins())
    if identifier == "CV032":
        from sqrt2_power_horner_trace import horner_trace_source_pins
        result.update(horner_trace_source_pins())
    if identifier == "CV033":
        from sqrt2_power_geometric_horner import geometric_horner_source_pins
        result.update(geometric_horner_source_pins())
    if identifier == "CV034":
        from sqrt2_power_composition_evaluation import composition_evaluation_source_pins
        result.update(composition_evaluation_source_pins())
    if identifier == "CV035":
        from sqrt2_power_horner_linearity import horner_linearity_source_pins
        result.update(horner_linearity_source_pins())
    if identifier == "CV036":
        from sqrt2_power_horner_zero_tail import horner_zero_tail_source_pins
        result.update(horner_zero_tail_source_pins())
    if identifier == "CV037":
        from sqrt2_power_horner_weighted_sum import horner_weighted_sum_source_pins
        result.update(horner_weighted_sum_source_pins())
    if identifier == "CV038":
        from sqrt2_power_geometric_weights import geometric_weights_source_pins
        result.update(geometric_weights_source_pins())
    if identifier == "CV039":
        from sqrt2_power_constructed_horner_sum import constructed_horner_sum_source_pins
        result.update(constructed_horner_sum_source_pins())
    if identifier == "CV040":
        from sqrt2_power_horner_monomials import horner_monomials_source_pins
        result.update(horner_monomials_source_pins())
    if identifier == "CV041":
        from sqrt2_power_convolution_weights import convolution_weights_source_pins
        result.update(convolution_weights_source_pins())
    if identifier == "CV042":
        from sqrt2_power_weighted_convolution import weighted_convolution_source_pins
        result.update(weighted_convolution_source_pins())
    if identifier == "CV043":
        from sqrt2_power_shifted_scaled_sum import shifted_scaled_sum_source_pins
        result.update(shifted_scaled_sum_source_pins())
    if identifier == "CV044":
        from sqrt2_power_cauchy_grid import cauchy_grid_source_pins
        result.update(cauchy_grid_source_pins())
    if identifier == "CV045":
        from sqrt2_power_cauchy_row_sum import cauchy_row_sum_source_pins
        result.update(cauchy_row_sum_source_pins())
    if identifier == "CV046":
        from sqrt2_power_cauchy_column_sum import cauchy_column_sum_source_pins
        result.update(cauchy_column_sum_source_pins())
    if identifier == "CV047":
        from sqrt2_power_cauchy_grid_sums import cauchy_grid_sums_source_pins
        result.update(cauchy_grid_sums_source_pins())
    if identifier == "CV048":
        from sqrt2_power_convolution_total import convolution_total_source_pins
        result.update(convolution_total_source_pins())
    if identifier == "CV049":
        from sqrt2_power_horner_product import horner_product_source_pins
        result.update(horner_product_source_pins())
    if identifier == "CV050":
        from sqrt2_power_convolution_locality import convolution_locality_source_pins
        result.update(convolution_locality_source_pins())
    if identifier == "CV051":
        from sqrt2_power_power_width_transport import power_width_transport_source_pins
        result.update(power_width_transport_source_pins())
    if identifier == "CV052":
        from sqrt2_power_composition_width_transport import composition_width_transport_source_pins
        result.update(composition_width_transport_source_pins())
    if identifier == "CV053":
        from sqrt2_power_convolution_upper_support import convolution_upper_support_source_pins
        result.update(convolution_upper_support_source_pins())
    if identifier == "CV054":
        from sqrt2_power_power_upper_support import power_upper_support_source_pins
        result.update(power_upper_support_source_pins())
    if identifier == "CV055":
        from sqrt2_power_horner_prefix_transport import horner_prefix_transport_source_pins
        result.update(horner_prefix_transport_source_pins())
    if identifier == "CV056":
        from sqrt2_power_supported_horner_product import supported_horner_product_source_pins
        result.update(supported_horner_product_source_pins())
    if identifier == "RN002":
        from sqrt2_power_rational_norm_product import rational_norm_product_source_pins
        result.update(rational_norm_product_source_pins())
    if identifier == "SI001":
        from sqrt2_power_signed_product_nonzero import signed_product_nonzero_source_pins
        result.update(signed_product_nonzero_source_pins())
    if identifier == "RN001":
        from sqrt2_power_rational_norm_transport import rational_norm_transport_source_pins
        result.update(rational_norm_transport_source_pins())
    if identifier == "QN001":
        from sqrt2_power_quadratic_nonzero import quadratic_nonzero_source_pins
        result.update(quadratic_nonzero_source_pins())
    if identifier == "QF001":
        from sqrt2_power_quadratic_product_trace import quadratic_product_trace_source_pins
        result.update(quadratic_product_trace_source_pins())
    if identifier == "QF002":
        from sqrt2_power_quadratic_trace_exists import quadratic_trace_exists_source_pins
        result.update(quadratic_trace_exists_source_pins())
    if identifier == "QF003":
        from sqrt2_power_quadratic_product_exists import quadratic_product_exists_source_pins
        result.update(quadratic_product_exists_source_pins())
    if identifier == "QH001":
        from sqrt2_power_quadratic_height import quadratic_height_source_pins
        result.update(quadratic_height_source_pins())
    if identifier == "QF004":
        from sqrt2_power_canonical_quadratic_trace import canonical_quadratic_trace_source_pins
        result.update(canonical_quadratic_trace_source_pins())
    if identifier == "QH002":
        from sqrt2_power_quadratic_trace_height import quadratic_trace_height_source_pins
        result.update(quadratic_trace_height_source_pins())
    if identifier == "QF005":
        from sqrt2_power_bounded_quadratic_product import bounded_quadratic_product_source_pins
        result.update(bounded_quadratic_product_source_pins())
    return result


def target_for(identifier):
    if type(identifier) is not str or identifier not in CASES:
        raise ValueError("unknown exact wave target")
    if identifier == "QN001":
        from sqrt2_power_quadratic_nonzero import frozen_quadratic_nonzero_target
        return frozen_quadratic_nonzero_target()
    if identifier == "QF001":
        from sqrt2_power_quadratic_product_trace import frozen_quadratic_product_trace_target
        return frozen_quadratic_product_trace_target()
    if identifier == "QF002":
        from sqrt2_power_quadratic_trace_exists import frozen_quadratic_trace_exists_target
        return frozen_quadratic_trace_exists_target()
    if identifier == "QF003":
        from sqrt2_power_quadratic_product_exists import frozen_quadratic_product_exists_target
        return frozen_quadratic_product_exists_target()
    if identifier == "QH001":
        from sqrt2_power_quadratic_height import frozen_quadratic_height_target
        return frozen_quadratic_height_target()
    if identifier == "QF004":
        from sqrt2_power_canonical_quadratic_trace import frozen_canonical_quadratic_trace_target
        return frozen_canonical_quadratic_trace_target()
    if identifier == "QH002":
        from sqrt2_power_quadratic_trace_height import frozen_quadratic_trace_height_target
        return frozen_quadratic_trace_height_target()
    if identifier == "QF005":
        from sqrt2_power_bounded_quadratic_product import frozen_bounded_quadratic_product_target
        return frozen_bounded_quadratic_product_target()
    if identifier == "RN001":
        from sqrt2_power_rational_norm_transport import frozen_rational_norm_transport_target
        return frozen_rational_norm_transport_target()
    if identifier == "SI001":
        from sqrt2_power_signed_product_nonzero import frozen_signed_product_nonzero_target
        return frozen_signed_product_nonzero_target()
    if identifier == "RN002":
        from sqrt2_power_rational_norm_product import frozen_rational_norm_product_target
        return frozen_rational_norm_product_target()
    if identifier == "CV001":
        from sqrt2_power_convolution_vanishing import frozen_convolution_vanishing_target
        return frozen_convolution_vanishing_target()
    if identifier == "CV002":
        from sqrt2_power_logexp_recurrence import frozen_logexp_recurrence_target
        return frozen_logexp_recurrence_target()
    if identifier == "CV003":
        from sqrt2_power_natural_convolution import frozen_natural_convolution_target
        return frozen_natural_convolution_target()
    if identifier == "CV004":
        from sqrt2_power_series_power_trace import frozen_series_power_trace_target
        return frozen_series_power_trace_target()
    if identifier == "CV005":
        from sqrt2_power_series_power_vanishing import frozen_series_power_vanishing_target
        return frozen_series_power_vanishing_target()
    if identifier == "CV006":
        from sqrt2_power_sum_linearity import frozen_sum_linearity_target
        return frozen_sum_linearity_target()
    if identifier == "CV007":
        from sqrt2_power_euler_product import frozen_euler_product_target
        return frozen_euler_product_target()
    if identifier == "CV008":
        from sqrt2_power_natural_fubini import frozen_natural_fubini_target
        return frozen_natural_fubini_target()
    if identifier == "CV009":
        from sqrt2_power_sum_splitting import frozen_sum_splitting_target
        return frozen_sum_splitting_target()
    if identifier == "CV010":
        from sqrt2_power_convolution_commutative import frozen_convolution_commutative_target
        return frozen_convolution_commutative_target()
    if identifier == "CV011":
        from sqrt2_power_sum_zero_tail import frozen_sum_zero_tail_target
        return frozen_sum_zero_tail_target()
    if identifier == "CV012":
        from sqrt2_power_triple_grid import frozen_triple_grid_target
        return frozen_triple_grid_target()
    if identifier == "CV013":
        from sqrt2_power_triple_row_sum import frozen_triple_row_sum_target
        return frozen_triple_row_sum_target()
    if identifier == "CV014":
        from sqrt2_power_convolution_associative import frozen_convolution_associative_target
        return frozen_convolution_associative_target()
    if identifier == "CV015":
        from sqrt2_power_convolution_linearity import frozen_convolution_linearity_target
        return frozen_convolution_linearity_target()
    if identifier == "CV016":
        from sqrt2_power_convolution_unit import frozen_convolution_unit_target
        return frozen_convolution_unit_target()
    if identifier == "CV017":
        from sqrt2_power_series_power_euler import frozen_series_power_euler_target
        return frozen_series_power_euler_target()
    if identifier == "CV018":
        from sqrt2_power_series_linear_combination import frozen_series_linear_combination_target
        return frozen_series_linear_combination_target()
    if identifier == "CV019":
        from sqrt2_power_weighted_series_trace import frozen_weighted_series_trace_target
        return frozen_weighted_series_trace_target()
    if identifier == "CV020":
        from sqrt2_power_shifted_euler_prefix import frozen_shifted_euler_prefix_target
        return frozen_shifted_euler_prefix_target()
    if identifier == "CV021":
        from sqrt2_power_finite_composition_euler import frozen_finite_composition_euler_target
        return frozen_finite_composition_euler_target()
    if identifier == "CV022":
        from sqrt2_power_exponential_weights import frozen_exponential_weights_target
        return frozen_exponential_weights_target()
    if identifier == "CV023":
        from sqrt2_power_weighted_series_scaling import frozen_weighted_series_scaling_target
        return frozen_weighted_series_scaling_target()
    if identifier == "CV024":
        from sqrt2_power_denominator_euler import frozen_denominator_euler_target
        return frozen_denominator_euler_target()
    if identifier == "CV025":
        from sqrt2_power_atanh_coefficients import frozen_atanh_coefficients_target
        return frozen_atanh_coefficients_target()
    if identifier == "CV026":
        from sqrt2_power_atanh_euler import frozen_atanh_euler_target
        return frozen_atanh_euler_target()
    if identifier == "CV027":
        from sqrt2_power_periodic_convolution import frozen_periodic_convolution_target
        return frozen_periodic_convolution_target()
    if identifier == "CV028":
        from sqrt2_power_composition_recurrence import frozen_composition_recurrence_target
        return frozen_composition_recurrence_target()
    if identifier == "CV029":
        from sqrt2_power_composition_coefficients import frozen_composition_coefficients_target
        return frozen_composition_coefficients_target()
    if identifier == "CV030":
        from sqrt2_power_weight_factorials import frozen_weight_factorials_target
        return frozen_weight_factorials_target()
    if identifier == "CV031":
        from sqrt2_power_normalized_composition import frozen_normalized_composition_target
        return frozen_normalized_composition_target()
    if identifier == "CV032":
        from sqrt2_power_horner_trace import frozen_horner_trace_target
        return frozen_horner_trace_target()
    if identifier == "CV033":
        from sqrt2_power_geometric_horner import frozen_geometric_horner_target
        return frozen_geometric_horner_target()
    if identifier == "CV034":
        from sqrt2_power_composition_evaluation import frozen_composition_evaluation_target
        return frozen_composition_evaluation_target()
    if identifier == "CV035":
        from sqrt2_power_horner_linearity import frozen_horner_linearity_target
        return frozen_horner_linearity_target()
    if identifier == "CV036":
        from sqrt2_power_horner_zero_tail import frozen_horner_zero_tail_target
        return frozen_horner_zero_tail_target()
    if identifier == "CV037":
        from sqrt2_power_horner_weighted_sum import frozen_horner_weighted_sum_target
        return frozen_horner_weighted_sum_target()
    if identifier == "CV038":
        from sqrt2_power_geometric_weights import frozen_geometric_weights_target
        return frozen_geometric_weights_target()
    if identifier == "CV039":
        from sqrt2_power_constructed_horner_sum import frozen_constructed_horner_sum_target
        return frozen_constructed_horner_sum_target()
    if identifier == "CV040":
        from sqrt2_power_horner_monomials import frozen_horner_monomials_target
        return frozen_horner_monomials_target()
    if identifier == "CV041":
        from sqrt2_power_convolution_weights import frozen_convolution_weights_target
        return frozen_convolution_weights_target()
    if identifier == "CV042":
        from sqrt2_power_weighted_convolution import frozen_weighted_convolution_target
        return frozen_weighted_convolution_target()
    if identifier == "CV043":
        from sqrt2_power_shifted_scaled_sum import frozen_shifted_scaled_sum_target
        return frozen_shifted_scaled_sum_target()
    if identifier == "CV044":
        from sqrt2_power_cauchy_grid import frozen_cauchy_grid_target
        return frozen_cauchy_grid_target()
    if identifier == "CV045":
        from sqrt2_power_cauchy_row_sum import frozen_cauchy_row_sum_target
        return frozen_cauchy_row_sum_target()
    if identifier == "CV046":
        from sqrt2_power_cauchy_column_sum import frozen_cauchy_column_sum_target
        return frozen_cauchy_column_sum_target()
    if identifier == "CV047":
        from sqrt2_power_cauchy_grid_sums import frozen_cauchy_grid_sums_target
        return frozen_cauchy_grid_sums_target()
    if identifier == "CV048":
        from sqrt2_power_convolution_total import frozen_convolution_total_target
        return frozen_convolution_total_target()
    if identifier == "CV049":
        from sqrt2_power_horner_product import frozen_horner_product_target
        return frozen_horner_product_target()
    if identifier == "CV050":
        from sqrt2_power_convolution_locality import frozen_convolution_locality_target
        return frozen_convolution_locality_target()
    if identifier == "CV051":
        from sqrt2_power_power_width_transport import frozen_power_width_transport_target
        return frozen_power_width_transport_target()
    if identifier == "CV052":
        from sqrt2_power_composition_width_transport import frozen_composition_width_transport_target
        return frozen_composition_width_transport_target()
    if identifier == "CV053":
        from sqrt2_power_convolution_upper_support import frozen_convolution_upper_support_target
        return frozen_convolution_upper_support_target()
    if identifier == "CV054":
        from sqrt2_power_power_upper_support import frozen_power_upper_support_target
        return frozen_power_upper_support_target()
    if identifier == "CV055":
        from sqrt2_power_horner_prefix_transport import frozen_horner_prefix_transport_target
        return frozen_horner_prefix_transport_target()
    if identifier == "CV056":
        from sqrt2_power_supported_horner_product import frozen_supported_horner_product_target
        return frozen_supported_horner_product_target()
    if identifier in ("NG001", "SN002"):
        from sqrt2_power_norm_separation import frozen_natural_gap_target, frozen_norm_separation_target
        return frozen_natural_gap_target() if identifier == "NG001" else frozen_norm_separation_target()
    if identifier == "SN003":
        from sqrt2_power_quadratic_norm_product import frozen_quadratic_norm_product_target
        return frozen_quadratic_norm_product_target()
    if identifier == "SN001":
        from sqrt2_power_signed_norm import frozen_signed_norm_target
        return frozen_signed_norm_target()
    if identifier == "IR016":
        from sqrt2_power_even_square import frozen_ir016_target
        return frozen_ir016_target()
    if identifier == "P10":
        from sqrt2_power_binary_dag import frozen_p10_targets
        return frozen_p10_targets()[0]
    if identifier in ("P08-eprover", "P08-vampire"):
        from sqrt2_power_solver_hints import P08_SOURCE
        from sqrt2_power_native import closed_formula
        return closed_formula(P08_SOURCE)
    if identifier in CHUNK_CASES:
        from sqrt2_power_composition_chunks import chunk_contract
        from sqrt2_power_native import closed_formula
        return closed_formula(chunk_contract(identifier)["source"])
    if identifier.startswith("P04-"):
        from sqrt2_power_formal_composition import contracts
        from sqrt2_power_native import closed_formula
        kind = "ground_instance" if identifier == "P04-ground" else "trace_soundness"
        return closed_formula(next(r for r in contracts() if r["target_kind"] == kind)["source"])
    if identifier in FOUNDATION_CASES:
        from sqrt2_power_rational_foundations import foundation_target
        return foundation_target(FOUNDATION_CASES[identifier])
    raise ValueError("unknown exact wave target")


def worker(identifier, hint=None):
    before = pins(identifier)
    target = target_for(identifier)
    if identifier == "QN001":
        from sqrt2_power_quadratic_nonzero import prove_quadratic_nonzero
        result = prove_quadratic_nonzero()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="quadratic_integer_binary_nonzero_not_finite_IR046")
    elif identifier == "QF001":
        from sqrt2_power_quadratic_product_trace import prove_quadratic_product_trace
        result = prove_quadratic_product_trace()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="quadratic_finite_trace_nonzero_not_trace_totality_or_real_IR046")
    elif identifier == "QF002":
        from sqrt2_power_quadratic_trace_exists import prove_quadratic_trace_exists
        result = prove_quadratic_trace_exists()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="unconditional_integer_quadratic_product_trace_existence_not_real_IR046")
    elif identifier == "QF003":
        from sqrt2_power_quadratic_product_exists import prove_quadratic_product_exists
        result = prove_quadratic_product_exists()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="witnessed_nonzero_integer_quadratic_finite_product_not_real_IR046")
    elif identifier == "QH001":
        from sqrt2_power_quadratic_height import prove_quadratic_height
        result = prove_quadratic_height()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="canonical_integer_quadratic_binary_height_not_finite_or_real_IR046")
    elif identifier == "QF004":
        from sqrt2_power_canonical_quadratic_trace import prove_canonical_quadratic_trace
        result = prove_canonical_quadratic_trace()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="canonical_integer_quadratic_trace_existence_not_finite_height_or_real_IR046")
    elif identifier == "QH002":
        from sqrt2_power_quadratic_trace_height import prove_quadratic_trace_height
        result = prove_quadratic_trace_height()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="canonical_integer_quadratic_finite_height_not_real_IR046")
    elif identifier == "QF005":
        from sqrt2_power_bounded_quadratic_product import prove_bounded_quadratic_product
        result = prove_bounded_quadratic_product()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="constructed_bounded_nonzero_integer_quadratic_finite_product_not_real_IR046")
    elif identifier == "RN001":
        from sqrt2_power_rational_norm_transport import prove_rational_norm_transport
        result = prove_rational_norm_transport()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="rational_norm_representative_transport_not_full_IR031")
    elif identifier == "SI001":
        from sqrt2_power_signed_product_nonzero import prove_signed_product_nonzero
        result = prove_signed_product_nonzero()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="signed_integer_binary_nonzero_not_quadratic_finite_IR046")
    elif identifier == "RN002":
        from sqrt2_power_rational_norm_product import prove_rational_norm_product
        result = prove_rational_norm_product()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="rational_norm_product_denominator_not_full_IR031")
    elif identifier == "CV001":
        from sqrt2_power_convolution_vanishing import prove_convolution_vanishing
        result = prove_convolution_vanishing()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="universal_natural_convolution_vanishing_not_IR079")
    elif identifier == "CV002":
        from sqrt2_power_logexp_recurrence import prove_logexp_recurrence
        result = prove_logexp_recurrence()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="all_indices_natural_logexp_recurrence_solution_not_composition_or_analytic_IR080")
    elif identifier == "CV003":
        from sqrt2_power_natural_convolution import prove_natural_convolution
        result = prove_natural_convolution()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="constructed_unique_finite_natural_convolution_not_power_tables_or_IR079")
    elif identifier == "CV004":
        from sqrt2_power_series_power_trace import prove_series_power_trace
        result = prove_series_power_trace()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="constructed_finite_natural_power_tables_not_vanishing_or_composition_IR079")
    elif identifier == "CV005":
        from sqrt2_power_series_power_vanishing import prove_series_power_vanishing
        result = prove_series_power_vanishing()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="constructed_natural_power_tables_vanish_below_exponent_not_composition_IR079")
    elif identifier == "CV006":
        from sqrt2_power_sum_linearity import prove_sum_linearity
        result = prove_sum_linearity()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="constructed_actual_weighted_natural_sum_linearity_not_formal_derivative_IR079")
    elif identifier == "CV007":
        from sqrt2_power_euler_product import prove_euler_product
        result = prove_euler_product()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="constructed_coefficientwise_natural_euler_product_rule_not_composition_IR079")
    elif identifier == "CV008":
        from sqrt2_power_natural_fubini import prove_natural_fubini
        result = prove_natural_fubini()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="constructed_all_rectangles_natural_fubini_not_convolution_associativity")
    elif identifier == "CV009":
        from sqrt2_power_sum_splitting import prove_sum_splitting
        result = prove_sum_splitting()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="constructed_natural_prefix_tail_sum_splitting_not_convolution_associativity")
    elif identifier == "CV010":
        from sqrt2_power_convolution_commutative import prove_convolution_commutative
        result = prove_convolution_commutative()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="constructed_commutative_natural_convolution_coefficients_not_associativity")
    elif identifier == "CV011":
        from sqrt2_power_sum_zero_tail import prove_sum_zero_tail
        result = prove_sum_zero_tail()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="actual_zero_tail_finite_sum_transport_not_convolution_associativity")
    elif identifier == "CV012":
        from sqrt2_power_triple_grid import prove_triple_grid
        result = prove_triple_grid()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="constructed_actual_finite_triple_product_grid_not_sum_identities_or_associativity")
    elif identifier == "CV013":
        from sqrt2_power_triple_row_sum import prove_triple_row_sum
        result = prove_triple_row_sum()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="constructed_actual_triple_row_sum_as_scaled_convolution_not_associativity")
    elif identifier == "CV014":
        from sqrt2_power_convolution_associative import prove_convolution_associative
        result = prove_convolution_associative()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="constructed_natural_convolution_associativity_below_common_width_not_composition")
    elif identifier == "CV015":
        from sqrt2_power_convolution_linearity import prove_convolution_linearity
        result = prove_convolution_linearity()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="constructed_weighted_natural_convolution_linearity_not_composition")
    elif identifier == "CV016":
        from sqrt2_power_convolution_unit import prove_convolution_unit
        result = prove_convolution_unit()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="constructed_natural_convolution_unit_below_width_not_composition")
    elif identifier == "CV017":
        from sqrt2_power_series_power_euler import prove_series_power_euler
        result = prove_series_power_euler()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="constructed_all_exponents_natural_euler_power_rule_not_composition")
    elif identifier == "CV018":
        from sqrt2_power_series_linear_combination import prove_series_linear_combination
        result = prove_series_linear_combination()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="constructed_weighted_natural_prefix_and_convolution_values_not_composition")
    elif identifier == "CV019":
        from sqrt2_power_weighted_series_trace import prove_weighted_series_trace
        result = prove_weighted_series_trace()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="constructed_all_lengths_weighted_series_accumulation_trace_not_chain_rule")
    elif identifier == "CV020":
        from sqrt2_power_shifted_euler_prefix import prove_shifted_euler_prefix
        result = prove_shifted_euler_prefix()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="constructed_shifted_euler_coefficient_table_not_chain_rule_or_analytic_derivative")
    elif identifier == "CV021":
        from sqrt2_power_finite_composition_euler import prove_finite_composition_euler
        result = prove_finite_composition_euler()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="constructed_finite_composition_euler_chain_rule_not_exponential_or_analytic_identity")
    elif identifier == "CV022":
        from sqrt2_power_exponential_weights import prove_exponential_weights
        result = prove_exponential_weights()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="constructed_terminal_one_exponential_weight_recurrence_and_nonvanishing_not_factorial_interpretation")
    elif identifier == "CV023":
        from sqrt2_power_weighted_series_scaling import prove_weighted_series_scaling
        result = prove_weighted_series_scaling()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="constructed_weighted_traces_with_all_rows_scalar_transport_not_exp_or_analytic_identity")
    elif identifier == "CV024":
        from sqrt2_power_denominator_euler import prove_denominator_euler
        result = prove_denominator_euler()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="constructed_denominator_cleared_finite_euler_equation_not_factorial_or_analytic_identity")
    elif identifier == "CV025":
        from sqrt2_power_atanh_coefficients import prove_atanh_coefficients
        result = prove_atanh_coefficients()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="constructed_denominator_cleared_odd_reciprocal_prefix_not_logarithm_identity")
    elif identifier == "CV026":
        from sqrt2_power_atanh_euler import prove_atanh_euler
        result = prove_atanh_euler()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="constructed_atanh_euler_table_with_initial_values_and_period_two_not_analytic_derivative")
    elif identifier == "CV027":
        from sqrt2_power_periodic_convolution import prove_periodic_convolution
        result = prove_periodic_convolution()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="constructed_convolution_coefficients_of_period_two_prefix_not_exp_or_analytic_identity")
    elif identifier == "CV028":
        from sqrt2_power_composition_recurrence import prove_composition_recurrence
        result = prove_composition_recurrence()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="constructed_actual_finite_composition_three_term_recurrence_not_initial_values_or_analytic_identity")
    elif identifier == "CV029":
        from sqrt2_power_composition_coefficients import prove_composition_coefficients
        result = prove_composition_coefficients()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="constructed_actual_finite_composition_initial_and_all_coefficients_not_factorial_or_analytic_identity")
    elif identifier == "CV030":
        from sqrt2_power_weight_factorials import prove_weight_factorials
        result = prove_weight_factorials()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="constructed_actual_weight_factorial_power_normalization_not_rational_or_analytic_identity")
    elif identifier == "CV031":
        from sqrt2_power_normalized_composition import prove_normalized_composition
        result = prove_normalized_composition()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="same_actual_composition_weights_normalized_by_factorial_powers_not_rational_evaluation_or_analytic_identity")
    elif identifier == "CV032":
        from sqrt2_power_horner_trace import prove_horner_trace
        result = prove_horner_trace()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="constructed_integer_horner_trace_with_all_in_range_value_uniqueness_not_rational_or_analytic_identity")
    elif identifier == "CV033":
        from sqrt2_power_geometric_horner import prove_geometric_horner
        result = prove_geometric_horner()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="constructed_horner_value_and_nonzero_power_with_exact_geometric_remainder_given_all_coefficients_not_analytic_identity")
    elif identifier == "CV034":
        from sqrt2_power_composition_evaluation import prove_composition_evaluation
        result = prove_composition_evaluation()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="constructed_normalized_composition_and_same_coefficients_horner_value_with_exact_geometric_remainder_not_analytic_identity")
    elif identifier == "CV035":
        from sqrt2_power_horner_linearity import prove_horner_linearity
        result = prove_horner_linearity()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="constructed_three_horner_evaluations_with_weighted_linearity_from_pointwise_relation_not_multiplication_or_analytic_identity")
    elif identifier == "CV036":
        from sqrt2_power_horner_zero_tail import prove_horner_zero_tail
        result = prove_horner_zero_tail()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="constructed_horner_endpoints_and_actual_power_with_exact_zero_tail_scaling_not_multiplication_or_analytic_identity")
    elif identifier == "CV037":
        from sqrt2_power_horner_weighted_sum import prove_horner_weighted_sum
        result = prove_horner_weighted_sum()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="constructed_horner_endpoint_equals_actual_sum_given_geometric_weights_and_pointwise_products_not_their_existence_or_analytic_identity")
    elif identifier == "CV038":
        from sqrt2_power_geometric_weights import prove_geometric_weights
        result = prove_geometric_weights()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="constructed_terminal_one_geometric_weights_and_actual_power_with_all_weight_power_identities_not_weighted_term_existence_or_analytic_identity")
    elif identifier == "CV039":
        from sqrt2_power_constructed_horner_sum import prove_constructed_horner_sum
        result = prove_constructed_horner_sum()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="constructed_geometric_weights_actual_power_pointwise_products_horner_trace_and_actual_sum_for_same_endpoint_not_multiplication_or_analytic_identity")
    elif identifier == "CV040":
        from sqrt2_power_horner_monomials import prove_horner_monomials
        result = prove_horner_monomials()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="constructed_same_horner_sum_with_exact_complementary_power_and_monomial_terms_not_multiplication_or_analytic_identity")
    elif identifier == "CV041":
        from sqrt2_power_convolution_weights import prove_convolution_weights
        result = prove_convolution_weights()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="constructed_three_geometric_tables_with_convolution_weight_product_law_via_actual_archived_power_add_not_full_evaluation_or_analytic_identity")
    elif identifier == "CV042":
        from sqrt2_power_weighted_convolution import prove_weighted_convolution
        result = prove_weighted_convolution()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="actual_coefficient_weighting_identity_for_all_indices_given_three_weight_tables_and_two_product_prefixes_not_full_evaluation_or_analytic_identity")
    elif identifier == "CV043":
        from sqrt2_power_shifted_scaled_sum import prove_shifted_scaled_sum
        result = prove_shifted_scaled_sum()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="constructed_sum_values_for_actual_scaled_shifted_block_with_leading_and_trailing_zeros_not_full_convolution_evaluation_or_analytic_identity")
    elif identifier == "CV044":
        from sqrt2_power_cauchy_grid import prove_cauchy_grid
        result = prove_cauchy_grid()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="constructed_square_cauchy_grid_from_actual_zero_padded_antidiagonal_products_and_triangular_zeros_not_row_column_sum_or_evaluation_identity")
    elif identifier == "CV045":
        from sqrt2_power_cauchy_row_sum import prove_cauchy_row_sum
        result = prove_cauchy_row_sum()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="constructed_cauchy_grid_and_all_actual_row_sums_identified_with_convolution_coefficients_using_proved_zero_tail_not_column_sums_or_evaluation_identity")
    elif identifier == "CV046":
        from sqrt2_power_cauchy_column_sum import prove_cauchy_column_sum
        result = prove_cauchy_column_sum()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="actual_complete_cauchy_column_sum_equals_padded_left_value_times_right_sum_under_explicit_span_equality_not_unconditional_grid_columns_or_evaluation")
    elif identifier == "CV047":
        from sqrt2_power_cauchy_grid_sums import prove_cauchy_grid_sums
        result = prove_cauchy_grid_sums()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="constructed_single_cauchy_grid_and_all_full_length_row_column_sums_with_shared_right_sum_and_zero_columns_not_yet_fubini_sum_product_or_evaluation")
    elif identifier == "CV048":
        from sqrt2_power_convolution_total import prove_convolution_total
        result = prove_convolution_total()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="constructed_full_length_natural_convolution_and_all_three_sums_with_output_sum_equal_to_product_of_input_sums_via_actual_fubini_not_horner_or_analytic_identity")
    elif identifier == "CV049":
        from sqrt2_power_horner_product import prove_horner_product
        result = prove_horner_product()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="constructed_full_length_convolution_and_actual_three_horner_traces_with_exact_extra_multiplier_product_law_including_zero_multiplier_not_truncated_evaluation_or_analytic_identity")
    elif identifier == "CV050":
        from sqrt2_power_convolution_locality import prove_convolution_locality
        result = prove_convolution_locality()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="constructed_common_actual_coefficient_from_two_local_padded_input_transports_below_explicit_strict_cutoff_not_all_degree_or_analytic_equality")
    elif identifier == "CV051":
        from sqrt2_power_power_width_transport import prove_power_width_transport
        result = prove_power_width_transport()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="constructed_two_actual_power_traces_and_all_row_low_coefficient_transport_under_explicit_width_order_not_truncated_full_evaluation_equality")
    elif identifier == "CV052":
        from sqrt2_power_composition_width_transport import prove_composition_width_transport
        result = prove_composition_width_transport()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="constructed_cross_width_powers_and_weighted_compositions_preserving_all_low_coefficients_with_same_input_and_weights_not_full_evaluation_or_tail_identity")
    elif identifier == "CV053":
        from sqrt2_power_convolution_upper_support import prove_convolution_upper_support
        result = prove_convolution_upper_support()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="constructed_actual_convolution_with_output_zero_after_sum_of_explicit_input_cutoffs_not_power_support_or_analytic_tail_estimate")
    elif identifier == "CV054":
        from sqrt2_power_power_upper_support import prove_power_upper_support
        result = prove_power_upper_support()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="constructed_actual_power_trace_with_every_row_zero_at_and_above_one_plus_exponent_times_input_length_including_unit_and_empty_cases_not_evaluation_or_analytic_identity")
    elif identifier == "CV055":
        from sqrt2_power_horner_prefix_transport import prove_horner_prefix_transport
        result = prove_horner_prefix_transport()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="constructed_same_actual_horner_history_for_matching_shorter_input_prefix_and_its_endpoint_not_equality_of_different_length_endpoints")
    elif identifier == "CV056":
        from sqrt2_power_supported_horner_product import prove_supported_horner_product
        result = prove_supported_horner_product()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="constructed_support_complete_shorter_convolution_horner_product_with_actual_power_scaling_and_extra_multiplier_no_cancellation_or_arbitrary_truncation_identity")
    elif identifier in ("NG001", "SN002"):
        from sqrt2_power_norm_separation import prove_natural_gap, prove_norm_separation
        result = prove_natural_gap() if identifier == "NG001" else prove_norm_separation()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage=("universal_natural_gap_not_full_campaign"
            if identifier == "NG001" else "signed_norm_integer_gap_not_full_IR032"))
    elif identifier == "SN003":
        from sqrt2_power_quadratic_norm_product import prove_quadratic_norm_product
        result = prove_quadratic_norm_product()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="signed_norm_multiplicativity_not_rational_IR031")
    elif identifier == "SN001":
        from sqrt2_power_signed_norm import prove_signed_norm_zero
        result = prove_signed_norm_zero()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="signed_norm_zero_core_not_IR032")
    elif identifier == "IR016":
        from sqrt2_power_even_square import prove_ir016
        result = prove_ir016()
        payload = result.payload
        diagnostics = dict(result.provenance, coverage="IR016_natural_core_not_full_irrationality")
    elif identifier == "P10":
        from sqrt2_power_binary_dag import prove_p10
        result = prove_p10()
        payload = result.payload
        diagnostics = dict(strategy="per_operation_shared_ordinary_HA_DAG",
            local_nodes=len(result.bundle.nodes), body_nodes=result.receipt.total_body_nodes,
            max_proof_depth=result.max_proof_depth, basis_names=result.basis_names,
            subleaf_node=result.subleaf_node, coverage="full_fixed_P10_not_IR064")
    elif identifier in CHUNK_CASES:
        from sqrt2_power_composition_chunks import prove_chunk
        from sqrt2_power_native import Basis
        result = prove_chunk(identifier, Basis(), expected_ast_sha256=formula_sha256(target))
        payload = result.bundle_certificate.payload
        diagnostics = result.manifest
    elif identifier.startswith("P04-"):
        from sqrt2_power_formal_composition import prove_ground_instance_dag, prove_trace_soundness
        from sqrt2_power_native import Basis
        if identifier == "P04-ground":
            result = prove_ground_instance_dag(Basis(), expected_ast_sha256=formula_sha256(target))
            payload = result.bundle_certificate.payload
            diagnostics = result.manifest
        else:
            result = prove_trace_soundness(Basis(), expected_ast_sha256=formula_sha256(target))
            payload = encode_proof_bundle(ProofBundle((BundleNode(0, target, (), result.certificate),), 0), target, limits=LIMITS)
            diagnostics = result.manifest
    elif identifier in FOUNDATION_CASES:
        from sqrt2_power_rational_foundations import prove_foundation
        actual, proof, diagnostics = prove_foundation(FOUNDATION_CASES[identifier])
        if actual != target:
            raise ValueError("foundation differs from named target")
        payload = encode_proof_bundle(ProofBundle((BundleNode(0, target, (), proof),), 0), target, limits=LIMITS)
        diagnostics = dict(diagnostics, coverage="full_named_rational_foundation_not_IR001",
            solver_role="independent_Z3_conjecture_check_not_imported_in_native_proof")
    else:
        from sqrt2_power_solver_hints import reconstruct_p08
        if type(hint) is not dict or set(hint) != {"problem", "observed", "contract"}:
            raise ValueError("actual source-bound solver hint required")
        if hint["observed"].get("solver") != identifier[4:]:
            raise ValueError("wrong solver hint")
        actual, proof, diagnostics = reconstruct_p08(hint["problem"], hint["observed"], hint["contract"])
        if actual != target:
            raise ValueError("reconstruction changed target")
        bundle = ProofBundle((BundleNode(0, target, (), proof),), 0)
        payload = encode_proof_bundle(bundle, target, limits=LIMITS)
        receipt = check_proof_bundle(bundle, target, limits=LIMITS)
        diagnostics = dict(diagnostics, body_nodes=receipt.total_body_nodes,
            coverage="P08_supporting_leaf_not_full_pilot")
    if before != pins(identifier):
        raise ValueError("sources changed during generation")
    return dict(schema=SCHEMA, case=identifier, status="native_generated",
        source_pins=before, target_ast_sha256=formula_sha256(target), bundle=payload,
        bundle_sha256=sha256(payload.encode()).hexdigest(), diagnostics=diagnostics,
        IR_parents_closed=0, model_proof_search_calls=0, independent_lean_checked=False)


def replay(identifier, value):
    before = pins(identifier)
    target = target_for(identifier)
    if (type(value) is not dict or value.get("schema") != SCHEMA
        or value.get("case") != identifier or value.get("source_pins") != before
        or value.get("status") != "native_generated"
        or value.get("target_ast_sha256") != formula_sha256(target)):
        raise ValueError("changed or unbound producer output")
    payload = value.get("bundle")
    if type(payload) is not str or sha256(payload.encode()).hexdigest() != value.get("bundle_sha256"):
        raise ValueError("changed certificate bytes")
    bundle, encoded_target = decode_proof_bundle(payload, limits=LIMITS)
    if encoded_target != target:
        raise ValueError("bundle does not prove exact independently bound target")
    receipt = check_proof_bundle(bundle, target, limits=LIMITS)
    corrupt = replace(bundle, nodes=tuple(replace(n, body=EqRefl(Zero()))
        if n.node_id == bundle.root else n for n in bundle.nodes))
    for candidate, claimed in ((bundle, Bot()), (corrupt, target)):
        try:
            check_proof_bundle(candidate, claimed, limits=LIMITS)
        except ProofBundleError:
            pass
        else:
            raise ValueError("false target or forged root accepted")
    if before != pins(identifier):
        raise ValueError("sources changed during fresh replay")
    return dict(schema=SCHEMA, case=identifier, status="fresh_ordinary_HA_checked",
        target_ast_sha256=formula_sha256(target), bundle_sha256=value["bundle_sha256"],
        source_pins=before, local_nodes=len(bundle.nodes), proof_nodes=receipt.total_body_nodes,
        kernel_calls=receipt.kernel_calls, original_target_checked=True,
        empty_context=True, false_target_rejected=True, forged_body_rejected=True,
        IR_parents_closed=0, library_admissions=0, independent_lean_checked=False)


def run(identifier, output, vampire=None):
    if output.exists() or output.is_symlink():
        raise ValueError("observation path must be new")
    before = pins(identifier)
    started = time.monotonic()
    deadline = started + 90
    records, results = {}, {}
    report = dict(schema=SCHEMA, case=identifier, source_pins=before,
        authority="local_observation_not_library_admission", source_snapshots={},
        status="not_checked", IR_parents_closed=0, library_admissions=0,
        independent_lean_checked=False, model_proof_search_calls=0)
    with controller_deadline(deadline):
        budget = LeafBudget(deadline)
        worker_input = b""
        if identifier.startswith("P08-"):
            from sqrt2_power_external import ExternalBudget, export_problem, invoke_solver
            from sqrt2_power_pilot_contracts import contracts
            contract = next(r for r in contracts() if r["pilot_id"] == "P08")
            solver = identifier[4:]
            problem = export_problem(contract["source"], tuple((r["name"], r["source"])
                for r in contract["allowed_external_premises"]), format="tptp")
            external_budget = ExternalBudget(cpu_seconds=6, wall_seconds=8)
            observed = invoke_solver(problem, solver, budget=external_budget, seconds=2,
                executable=vampire if solver == "vampire" else None)
            # Same outer case budget; no reservation refund after a fast solver.
            budget.reserved_cpu += external_budget.snapshot()["cpu_hard_limit_reserved_seconds"]
            hint = dict(problem=problem, observed=observed, contract=contract)
            worker_input = canonical(hint)
            save_new(output / "live-solver-input-and-observation.json.gz", gzip.compress(worker_input, mtime=0))
            report["live_external"] = dict(solver=solver, status=observed["observation"],
                binary=observed["capability"].get("binary"), budget=external_budget.snapshot(),
                observation_sha256=sha256(worker_input).hexdigest(), HA_authority=False)
        elif identifier in FOUNDATION_CASES or identifier in ("NG001", "RN001", "RN002", "SI001", "QH001"):
            from sqrt2_power_external import ExternalBudget, export_problem, invoke_solver
            from peano_lab.kernel.formulas import pretty_formula
            problem = export_problem(pretty_formula(target_for(identifier), []), format="smt2")
            external_budget = ExternalBudget(cpu_seconds=6, wall_seconds=8)
            observed = invoke_solver(problem, "z3", budget=external_budget, seconds=2)
            budget.reserved_cpu += external_budget.snapshot()["cpu_hard_limit_reserved_seconds"]
            raw_external = canonical(dict(problem=problem, observed=observed))
            save_new(output / "live-solver-input-and-observation.json.gz", gzip.compress(raw_external, mtime=0))
            report["live_external"] = dict(solver="z3", status=observed["observation"],
                binary=observed["capability"].get("binary"), budget=external_budget.snapshot(),
                observation_sha256=sha256(raw_external).hexdigest(), HA_authority=False,
                role="independent_conjecture_check_not_used_for_reconstruction")
        generated = budget.run((sys.executable, "-B", str(SCRIPT), "--worker", identifier),
            cpu=28, wall=40, input_bytes=worker_input)
        records["generation"] = generated
        if successful(generated):
            value = json.loads(generated["stdout"])
            if value.get("source_pins") != before:
                raise ValueError("producer did not use controller sources")
            results["generation"] = {k:v for k,v in value.items() if k != "bundle"}
            checked = budget.run((sys.executable, "-B", str(SCRIPT), "--replay", identifier),
                cpu=20, wall=30, input_bytes=canonical(value))
            records["fresh_replay"] = checked
            if successful(checked):
                accepted = json.loads(checked["stdout"])
                if (accepted.get("status") != "fresh_ordinary_HA_checked"
                    or accepted.get("source_pins") != before
                    or accepted.get("bundle_sha256") != value.get("bundle_sha256")):
                    raise ValueError("unexpected fresh replay result")
                results["fresh_replay"] = accepted
                report["status"] = "fresh_ordinary_HA_checked"
        if pins(identifier) != before:
            raise ValueError("controller inputs changed before archival")
        for name, pin in before.items():
            raw = (ROOT / name).read_bytes()
            if sha256(raw).hexdigest() != pin["sha256"] or len(raw) != pin["bytes"]:
                raise ValueError("changed source snapshot")
            stored = "sources/" + name + ".gz"
            save_new(output / stored, gzip.compress(raw, mtime=0))
            report["source_snapshots"][name] = stored
        for phase, process in records.items():
            raw = canonical(process)
            save_new(output / (phase + "-process.json.gz"), gzip.compress(raw, mtime=0))
        report.update(results=results, process_records={phase: dict(path=phase+"-process.json.gz",
            raw_sha256=sha256(canonical(process)).hexdigest(), reason=process["reason"],
            returncode=process["returncode"], resources=process["resources"])
            for phase, process in records.items() if process is not None},
            elapsed_wall_seconds=time.monotonic()-started,
            budget=dict(cpu_seconds=60, wall_seconds=90, max_workers=1, rss_bytes=768*1024**2,
                note="CPU reservations include each worker's one-second hard-limit margin"))
        save_new(output / "report.json", json.dumps(report, sort_keys=True, indent=2).encode()+b"\n")
    return {key: report[key] for key in ("case", "status", "elapsed_wall_seconds", "process_records")}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--worker", choices=CASES)
    group.add_argument("--replay", choices=CASES)
    group.add_argument("--run", choices=CASES)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--vampire", type=Path)
    args = parser.parse_args()
    if args.worker:
        hint = None
        if args.worker.startswith("P08-"):
            raw = sys.stdin.buffer.read(8*1024**2+1)
            if len(raw) > 8*1024**2:
                raise ValueError("solver hint input exceeds bound")
            hint = json.loads(raw)
        value = worker(args.worker, hint)
    elif args.replay:
        raw = sys.stdin.buffer.read(8*1024**2+1)
        if len(raw) > 8*1024**2:
            raise ValueError("replay input exceeds bound")
        value = replay(args.replay, json.loads(raw))
    else:
        if args.output is None:
            parser.error("--run requires --output")
        value = run(args.run, args.output, args.vampire)
    if "peano_lab.library.theorems" in sys.modules:
        raise ValueError("worker unexpectedly imported full theorem registry")
    print(canonical(value).decode(), flush=True)
